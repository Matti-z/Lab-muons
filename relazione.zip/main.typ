
//troviamo un titolo adatto

//aggiungiamo numero matricola, abbelliamo pagina iniziale

#set document(
  title: [Muon's decay time and parity symmetry breaking],
  author: (
    "Andrea Boldetti",
    "Giacomo Casanova",
    "Robert Friets",
    "Mattia Zorloni",
  ),
  date: auto,
)

// Impostazioni di pagina
#set page(
  paper: "a4",
  margin: (
    top: 2.5cm,
    bottom: 2.5cm,
    x: 2.5cm,
  ),
  numbering: "1",        // numerazione pagine: 1, 2, 3, ...
  // number-align: center,  // numero pagina centrato nel footer
  // header: [
  //   #set text(size: 9pt)
  //   Lab-muons 
  // ],
)

// Tipografia di base
#set text(
  size: 12pt,
  lang: "en",
  font: "New Computer Modern"
)

#set par(
  justify: true,
  leading: 1.2em,
  first-line-indent: 1em,
)

// ==== NUMERAZIONE ====

// Sezioni numerate 1, 1.1, 1.2, ...
#set heading(numbering: "1.1", supplement: [Sec.])


// Equazioni numerate (1), (1.1), ...

// reset counter at each chapter
// if you want to change the number of displayed 
// section numbers, change the level there
#show heading.where(level:1): it => {
  counter(math.equation).update(0)
  it
}

#set math.equation(numbering: n => {
  numbering("(1.1)", counter(heading).get().first(), n) },
  supplement: [Eq.],
  number-align: bottom,
)

#set math.lr(size: 120%)

// ==== IMPAGINAZIONE ====

#set heading(numbering: "1.1")

//level 1
#show heading.where(level: 1): set text(
  size: 24pt,
  weight: "bold",
)
#show heading.where(level: 1): set block(
  below: 1em,
)
// Pagina nuova per ogni capitolo
#show heading.where(level: 1): it => { pagebreak(weak: true); it }

//level 2
#show heading.where(level: 2): set text(
  size: 20pt,
  weight: "semibold",
)
#show heading.where(level: 2): set block(
  below: 1em,
  above: 2em
)

//level 3
#show heading.where(level: 3): set text(
  size: 14pt,
  weight: "semibold",
)

//set language of the caption of figures English
#set figure(supplement: [Figure])
#show figure.caption: set text(size: 10pt, style: "normal", font: "Atkinson Hyperlegible")
// ==== TITOLO ====

#show title: set align(center)
#show title: set text(size: 24pt, weight: "bold", font: "Libertinus Serif")
#show title: set block(below: 3em)



//copertina

#include "first_page.typ"

//Abstract

#include "Robert/abstract.typ"

// Indice 
#outline()

#pagebreak()


//List of figures, tables

// #outline(
//   title: [List of Figures],
//   target: figure.where(kind: image),
  
// )


// ==== TESTO ====

// Inclusione dei blocchi di testo.
#include "jack/mysection.typ"
#include "Robert/mysection.typ"
#include "Bolde/circuito.typ"
#include "Mattia/Scint_tests.typ" 
#include "Bolde/analysis.typ"
#include "jack/conclusion.typ"

#pagebreak()
// #{
//   set text(size: 11pt)

//   outline(
//     title: "List of Figures",
//     target: figure.where(kind: image),
//   )
// }
// #pagebreak()

#heading(level: 1, numbering: none)[List of Figures]

#{ set text(size: 11pt)
 outline( title: none, target: figure.where(kind: image), )}

#pagebreak()



#heading(level: 1, numbering: none)[List of Tables]
#{ set text(size: 11pt)
  outline(
  title: none,
  target: figure.where(kind: table) )
}


#show link: underline
#bibliography("bibliography.bib" , style:"american-physics-society")