#import "../preamble.typ": *
#import "@preview/subpar:0.2.2"

#let w=75.7%

= Theoretical Introduction

== Cosmic Rays and Atmospheric Muons 
<sec:atm_mu>

Primary Cosmic Rays are high energy astroparticles generated from outside of the Solar System and from Sun. When they enter the atmosphere, they interact with molecules in air, producing shower of secondary particles. Following interaction and decay processes, some particles reach the Earth surface.



Atmospheric muons are the most abundant charged particles reaching the surface. This is due to the small energy loss in the atmosphere, the small interaction cross section and a long lifetime, since its decay is mediated by weak interactions.

Atmospheric muons are mainly produced by the decay of secondary charged particles. The two main channels of production, with their branching ratios #cite(<PDG>), are:

$

pi ^plus.minus arrow mu ^plus.minus  op(nu_mu, limits: #true)^( (-) ) space space space B.R.: ( 99.98770±0.00004 ) % \

K ^plus.minus arrow mu ^plus.minus  op(nu_mu, limits: #true)^( (-) )  space space space B.R.: (  63.56±0.11 ) %

$






== Stopping power 
<sec:SP>

// bethe-bloch, why are MIP
\
When passing through matter, muons lose energy along their path inside the material. The average energy loss due to the interaction with matter, as a function of the energy of the muon, follows the expression:

$
(d E)/(d x) = a(E) + b(E) times E
$

where $a(E)$ is the contribution due to ionization and atomic  excitation of the material and $b(E) times E$ is the contribution due to bremsstrahlung, pair production, photonuclear emission and radiative loss.

In #ref(<fig:total_SP>) are shown the stopping power curves by varying the energy of the muon, for $3$ materials that will be used in this experiment and air. Polyvinyltoluene is the material of the detector used, while sodium chloride and aluminum will be used for specific measurements. Data are obtained from PDG #cite(<PDG>).

#figure(
  image("images/total_StoppingPower.pdf", width: w),
  caption: [Stopping power, as a function of the muon energy, for different materials],
)<fig:total_SP>


By integrating the inverse of the stopping power we can find the maximum range of muons through every material, using #ref(<eq:range_matter>). In #ref(<fig:lenght_in_mat>) is shown this relation as a function of energy.

$
Delta x (E)= integral_(0)^(x) d x = integral_0^E (d x)/(d E) d E
$<eq:range_matter>


#figure(
  image("images/Maximum_lenght.pdf", width: w),
  caption: [Length through matter for different material, and range in every material ],
)<fig:lenght_in_mat>


The horizontal line indicates the longest straight path a particle can perform in each material, taken as the diagonal of the smallest scintillator in our setup ($85.45$ cm). For Aluminum and Sodium Chloride we used blocks with surface similar to the one of the scintillator, and some centimeter different in heigh, causing to have a maximum length difference of the order $10^(-1)$ cm. Therefore only one line is showed, since in logarithmic scale the difference is visually  negligible. 


From #ref(<fig:lenght_in_mat>) we can extrapolate the energy range of stopped muons in the materials shown, taking all the energies for which the maximum length is under the line drawn in the graph.

#figure(
  image("images/total_StoppingPower_EnergyRange.pdf", width: w),
  caption: [Stopping power and energy ranges, as a function of the muon energy, for different materials],
)<fig:total_SP_E_range>

 In #ref(<fig:total_SP_E_range>) we can see the energy ranges thus obtained on the stopping power graph. This clearly shows that, for similar lengths, air adds a negligible contribute, since it has a smaller energies interval that can stop muons (with the same path length) and its stopping power is around $2$ orders of magnitude lower than the other materials considered.
\

We can now use this estimated energy range to also see the different contributions of the stopping power we enlisted before. In #ref(<fig:SP_contribution>) are showed all the different contributions for the $3$ materials we are interested in. 


//#block()[

//  #grid(columns: 2)[

 // #figure(
//  image("images/SP_contrib/StoppingPower_contributions_Polyvinyltoluene.pdf", width: 100%),
//  caption: [Stopping power contributions for \ Polyvinyltoluene],
//)<fig:SP_scint>
  
//][

//  #figure(
//  image("images/SP_contrib/StoppingPower_contributions_Sodium_chloride.pdf", width: 100%),
//  caption: [Stopping power contributions for \ Sodium chloride],
//)<fig:SP_salt>
//  
//]]

//  #figure(
//  image("images/SP_contrib/StoppingPower_contributions_Aluminum.pdf", width: 50%),
//  caption: [Stopping power contributions for Aluminum],
//)<fig:SP_al>

#subpar.grid(
   columns: (2fr,2fr) ,
  figure(image("images/SP_contrib/StoppingPower_contributions_Polyvinyltoluene.pdf", width: 114%), caption: [Polyvinyltoluene], ), 
  figure(image("images/SP_contrib/StoppingPower_contributions_Sodium_chloride.pdf", width: 114%), caption:[Sodium chloride]), 

  grid.cell(figure( image("images/SP_contrib/StoppingPower_contributions_Aluminum.pdf", width: 57%),
  caption: [Aluminum]) , colspan: 2), 
   
   caption: [Stopping power contributions for different materials],
   label: <fig:SP_contribution>,
 )

We can notice how, at low energies, the contribution of ionization is at least $4$ orders of magnitude more intense then the other contributions. Therefore we can assume that, for the energy range of our interest, only the ionization contribution can be considered.



//for low energies, it's ok to assume only bethe-bloch (see graph 13.2 in "messenger from the cosmos")




== Properties of Atmospheric Muons 
<chap:muons_prop>

Since the interaction with matter of $mu^-$ and  $mu^+$ is different, it is important to know the so called "muon charge ratio", defined as the ratio of positive and negative atmospheric muons. Different measures showed a muon charge ratio varying with the energy (as shown in #cite(<Kitagawa_2024>)). For low energy muons ($approx 1$ GeV) the muon charge ratio $R_mu = 1.18 plus.minus 0.02$ #cite(<BAHMANABADI2019162635>).

This gives a the probabilities to have a $mu^+$ and $mu^-$:

#block()[

#grid(columns: 3, column-gutter: 8em)[][
  $P_+ = ( 54.1 plus.minus 0.4) %$ 
][
  $P_- = ( 45.9 plus.minus 0.4) %$
]
]

\

Atmospheric muons' angular distribution depends on their energy, as shown in #ref(<fig:ang_distr>).

//#figure(
//  image("images/ratio_cos.jpg", width: w, height: 9/16 *w, fit: "stretch"),
//  caption: [Angular distributions of atmospheric muon for different energies #cite(<cecchini2012atmosphericmuonsexperimentalaspects>)],
//  placement: top
//)<fig:ratio_cos>

Muons with low energies (in which we are interested, as shown in the section #ref(<sec:SP>)) follow a $cos^n theta$ distribution, with $n approx 2/3$.

\

We are also interested in the muon flux at sea level for low energy particles. In #ref(<fig:mu_flux>) is reported the graph of the integral (in $c m^(-2) s r ^(-1) s^(-1)$) and differential (in $c m^(-2) s r ^(-1) s^(-1) ((G e V)/c)^(-1)$) muon spectra, as reported by _Rastin_ #ref(<BCRastin_1984>).

 #grid(
   columns: (2fr,1fr) ,
   grid.cell([ #figure(image("images/ratio_cos.jpg", width: w, height: 7/18 *w, fit: "stretch"),
  caption: [Angular distributions of atmospheric muon \ at different energies #cite(<cecchini2012atmosphericmuonsexperimentalaspects>)])<fig:ang_distr>]),
  
  grid.cell([ #v(11pt)
  #figure(image("images/muon_flux.png", width:w, height: 6.7/18 *w, fit: "stretch"),
  caption: [Integral (A) and \ differential (B) muon spectra #ref(<BCRastin_1984>)])<fig:mu_flux>])
 )


//#figure(
//  image("images/muon_flux.png", width:w),
//  caption: [Integral (A) and differential (B) muon spectra for vertical direction #ref(<BCRastin_1984>)]
//)<fig:mu_flux>

== Muons decay

Muon decays mainly ($approx 100 %$) into an electron and two "neutrinos" ($nu_mu + overline(nu)_e$ for $mu^-$, and $overline(nu)_mu + nu_e$ for $mu^+$), as shown in #ref(<fig:mu_beta_decay>):

#figure(caption: [Feynman diagrams of muon's $beta$ decays],
block()[
#grid(columns: 2, column-gutter: 5.5em)[
  #diagram(
    debug: false,
    let (p1, g1, p2, g2, v1, v2, label) = ((-0.5, 1), (2, 0), (3, 1), (3, 2), (1, 1), (2, 1.5), (1.8, 1.1)),
    node(p1 , [$mu^-$]),
    edge(p1 , v1 , "->-"),
    
    node( g1 , [$nu_mu$]),
    edge(g1 , v1, "-<-"),
    
    node(p2 , [$e^-$]),
    edge(p2 , v2 , "-<-"),
    
    node(g2 , [$overline(nu)_e$]),
    edge(g2 , v2 , "->-"),

    node( label, [$W^-$]),
    edge(v1 , v2 , "wave"))
  
][
  #diagram(
    debug: false,
    let (p1, g1, p2, g2, v1, v2, label) = ((-0.5, 1), (2, 0), (3, 1), (3, 2), (1, 1), (2, 1.5), (1.8, 1.1)),
    node(p1 , [$mu^+$]),
    edge(p1 , v1 , "-<-"),
    
    node( g1 , [$overline(nu)_mu$]),
    edge(g1 , v1, "->-"),
    
    node(p2 , [$e^+$]),
    edge(p2 , v2 , "->-"),
    
    node(g2 , [$nu_e$]),
    edge(g2 , v2 , "-<-"),

    node( label, [$W^+$]),
    edge(v1 , v2 , "wave"))
]

])<fig:mu_beta_decay>

\

The other possible decays are higher order diagrams of this $beta$ decay, those of which imply a photon emission #cite(<PDG>).
This means that, in order to measure muon lifetime, only a time measurement of the produced electron is needed.

//decay width?

Muon spontaneous decay time distribution follows an exponential, with a mean life $tau = (2.1969811 plus.minus 0.0000022) mu s $ (as listed in PDG #cite(<PDG>)).
Due to the exponential distribution, the time in which the $mu$ is generated is not needed, since every time offset can be reabsorbed in the coefficient of the distribution. Hence, also atmospheric muons can be used to measure $mu$ mean lifetime.


== $mu^-$ interaction with matter
<sec:mu_interaction>

// muon capture & Primakoff formula:  cross sections and decay time (SKK data on drive)


When a muon stops in matter, it is subject to electromagnetic potential of the nuclei. In this case, before decaying, the muon can be captured by an atom. Since it's not an electron, the captured muon is not subject to the Pauli exclusion principle, and it occupies the innermost orbital. Since the muon is more massive than the electron, his $1s$ orbital is less wide then the electron's one. Hence, the PDF of the muon has a non-negligible overlap with the protons in the nuclei, causing an interaction among them. The tree-level diagram of the interaction between the muon and the proton is showed in #ref(<fig:mu-p_interaction>).

//conviene ingrandire limmagine o placement: top, così che non ci sia spacio vuoto sotto

#figure(caption: [Feynman diagrams of $mu^- p$ interaction],
block()[
#grid(columns: 1, column-gutter: 5.5em)[
 #diagram(
    debug: false,
    let (p1, g1, p2, g2, v1, v2, u1, u2, d1, d2, labelW, labelP, labelN) = ((0,0), (3, 0), (0, 2), (3, 2), (1.5, 0.5), (1.5, 1.5), (0,2.3) ,(3,2.3), (0,2.6) , (3,2.6) , (1.8, 1.05) , (-0.5,2.3) ,(3.5,2.3) ),
    node(p1 , [$mu^-$]),
    edge(p1 , v1 , "->-"),
    
    node( g1 , [$nu_mu$]),
    edge(g1 , v1, "-<-"),
    
    node(p2 , [$u$]),
    edge(p2 , v2 , "->-"),
    
    node(g2 , [$d$]),
    edge(g2 , v2 , "-<-"),
    
    node(u1 , [$u$], shape: ellipse.with(scale:2.4) ,  stroke: .1em, width: 1em, height: 2em),
    node(labelP, [$p$]),
    node(u2 , [$u$], shape: ellipse.with(scale:2.4) ,  stroke: .1em, width: 1em, height: 2em),
    node(labelN, [$n$]),
    edge(u1,u2,"->-"),

    node(d1 , [$d$]),
    node(d2 , [$d$]),
    edge(d1,d2,"->-"),

    node( labelW, [$W$]),
    edge(v1 , v2 , "wave"))
    
    
]])<fig:mu-p_interaction>

In this process, the muon rest energy gets redistributed among the neutrino and the neutron. Due to the neutrino is non-interacting, we will not be able to see it, so we have to search for some evidence of the excitation of the neutron, since it will gain some energy from the muon mass. The excited neutron goes back to its fundamental state through different paths: it can simply emit a photon or it could lose its energy through internal conversion, emitting one of the orbital electrons of the atom. Since photons from radiative emission have energies comparable with ambient photons, that we already exclude because they form a disturbing background, we will not be able to detect them.


The capture rate of the muon will depend from the intensity of the EM interaction with the nuclei, so will depend on the $Z_("eff")$, as discussed by _Primakoff_ #cite(<RevModPhys.31.802>). The simplified Primakoff formula is reported in #ref(<eq:primakoff>)

$
Lambda_("cap") (A,Z) = Z_("eff")^4 X_1 [ 1 - X_2 [ (A-Z)/(2A) ] ],
$<eq:primakoff>

where $X_1$ is related the muon capture rate in hydrogen, $X_2$ is a factor that consider the Pauli exclusion principle in the nuclei, and $Z_("eff")$ is obtained as discussed by _Ford and Willis_  #cite(<PhysRev.185.1429>).

\

We are interested in the capture rate and in the mean life of captured muons inside Aluminum and Sodium Chloride. In advance, we should also consider the elements inside the scintillator as a possible nuclei capable of capturing the muon. But, as reported by _Suzuki et al._ #cite(<PhysRevC.35.2212>), in both Hydrogen and Carbon $mu^-$ has lifetimes similar to the vacuum one, with rates at least one order of magnitude smaller, that we are not able to distinguish. In #ref(<tab:mu_capt>) are reported those data from _Suzuki et al._#cite(<PhysRevC.35.2212>), and the $Z_("eff")$.



#figure( 
    table(
    columns: (auto, auto, auto, auto),
    align: (left, right, right, right),
    stroke: 0.5pt + luma(120),
    fill: (x, y) => if y == 0 { luma(240) } else { none },
    table.header(
      [*Element*], [*$Z_("eff")$*], [*$tau$*(ns)], [*$R$* (MHz)]
    ),
    [Al], [$11.48$],  [$864 plus.minus 2$],   [$0.662 plus.minus 0.003$], 
    [Na],                 [$9.95$],   [$1204 plus.minus 2$],  [$0.3772 plus.minus 0.0014$], 
    [Cl], [$14.24$],  [$560.8 plus.minus 2.0$],  [$1.333 plus.minus 0.006$],  
    
    
    // Use table.footer with #emph for italics
  ),
  caption: [Muon capture data for different elements, obtained from #cite(<PhysRevC.35.2212>).],
  supplement: [Table],
) <tab:mu_capt>

In order to obtain the decay time of captured muon in Sodium Chloride, we should take the weighted mean of the $tau$ of Na and Cl, taking into account the relative capture rate of those two elements.

\

#block()[

#grid(columns: 3, column-gutter: 3.8em)[][ 

#eq[$tau_("NaCl") = ( sum_(i=1)^2 R_i tau_i )/( sum_(i=1)^2 R_i )$ ]

][
  
#eq[$sigma_(tau_("NaCl")) = sqrt( sum_(i=1)^2 [ ( ( d tau_("NaCl") )/( d R_i ) sigma_( R_i ) )^2 + ( ( d tau_("NaCl") )/( d tau_i ) sigma_( tau_i ) )^2 ] )$ ]

]
  
]


with $i=1,2$ indicating, respectively, Na and Cl. By performing those calculations, we obtain

$
  tau_("NaCl") = ( 702.7 plus.minus 1.7 ) "ns".
$<eq:tau_NaCl>


Meanwhile, to obtain the total decay rate of captured muons in Sodium Chloride, we take the mean of the two rates.

#block()[

#grid(columns: 3, column-gutter: 7em)[][ 
#eq[$R_("NaCl") =  (sum_(i=1)^2 R_i )/2$ ]
][
#eq[$sigma_(R_("NaCl")) = sqrt( sum_(i=1)^2  ( ( d R_("NaCl") )/( d R_i ) sigma_( R_i ) )^2   )$ ]
]
  
]

with $i=1,2$ indicating, respectively, Na and Cl. By performing those calculations, we obtain

$
  R_("NaCl") = (  0.855 plus.minus 0.003 ) "MHz."
$<eq:R_NaCl>

\

Using those rates, we can now obtain the rate of muons, in each material, that decays freely or gets captured. The rate of the free decay is given by the $tau$ of the muon.

#block()[

#grid(columns: 3, column-gutter: 8.3em)[][ 
#eq[$R_("free") = Gamma_("tot") = 1/tau_mu $]
][
#eq[$sigma_(R_("free")) = ( sigma_tau )/( tau_mu^2 )$ ]
]
  
]

Using $tau_mu = (2.1969811 plus.minus 0.0000022) mu s $ we obtain

$
  R_("free") = ( 0.4551701 plus.minus 0.0000005 ) "MHz".
$<eq:R_free>

In a given material with rate of capture $R_(mat)$, we can compute the percentage of muons that decay freely and through capture. We only consider the error on $R_(mat)$ since the error on $R_("free")$ is various order of magnitude lower than the $sigma$ of the materials we are considering for this experiment.

#block()[

#grid(columns: 4, column-gutter: 3em)[][ 
#eq[ $R^%_("free") = ( R_("free") )/(  R_("free") + R_("mat") )$, ]

][
#eq[$R^%_("mat") = ( R_("mat") )/(  R_("free") + R_("mat") ) $, ]
][
#eq[$sigma_(R^%) = ( R_("free") sigma_( R_("mat") ) )/( ( R_("free") + R_("mat") )^2 )$. ]
]
  
]

#figure( 
    table(
    columns: (auto, auto, auto, auto),
    align: (left, right, right, right),
    stroke: 0.5pt + luma(120),
    fill: (x, y) => if y == 0 { luma(240) } else { none },
    table.header(
      [*Material*], [*$R^%_("free")$*], [*$R^%_("mat")$*], [*$sigma_(R^%)$*]
    ),
    [Al],   [$40.7%$],  [$59.3%$],  [$0.1%$], 
    [NaCl], [$34.74%$],  [$65.26%$],  [$0.08%$], 
      
  
    
    // Use table.footer with #emph for italics
  ),
  caption: [Probability that a muon decays freely or through capture in different materials.],
  supplement: [Table],
) <tab:decay_rates_mu->

== $mu^+$ interaction with matter

//muonium decay:  cross sections and decay time (SKK data on drive)

When a positive muon gets thermal inside a material, it can capture an electron to form the muonium $M = mu^+ e^-$. Due to the instability of $mu^+$ the muonium decays as shown in #ref(<fig:muonium_decay>).

#figure(caption: [Feynman diagrams of muonium decays],
block()[
#grid(columns: 2, column-gutter: 5.5em)[
  #diagram(
    debug: false,
    let (p1, g1, p2, g2, v1, v2, label) = ((0, 0), (0, 3), (3, 0), (3, 3), (1.5, 0.75), (1.5, 2.25), (1.8, 1.5)),

    node( p1, [$mu^+$]),
    edge( p1 , v1 , "-<-"),
    
    node( p2 , [$overline(nu)_mu$]),
    edge( v1 , p2 , "-<-"),

    node( g1, [$e^-$]),
    edge( g1 , v2 , "->-"),

    node( g2, [$nu_e$]),
    edge( v2 , g2 , "->-"),
  
    node( label, [$W$]),
    edge( v1 , v2 , "wave"),
  )
  
][
  #diagram(
    debug: false,
    let (p1, g1, p2, g2, v1, v2, label, e1, e2) = ((-0.5, 1), (2, 0), (3, 1), (3, 2), (1, 1), (2, 1.5), (1.8, 1.1), ( -0.5,2.5 ), ( 3,2.5 )),
    node( p1 , [$mu^+$]),
    edge( p1 , v1 , "-<-"),
    
    node( g1 , [$overline(nu)_mu$]),
    edge( g1 , v1, "->-"),
    
    node( p2 , [$e^+$]),
    edge( p2 , v2 , "->-"),
    
    node( g2 , [$nu_e$]),
    edge( g2 , v2 , "-<-"),

    node( label, [$W^+$]),
    edge( v1 , v2 , "wave"),
    
    node( e1, [$e^-$]),
    node( e2, [$e^-$]),
    edge( e1, e2, "->-")
  
  )
]

])<fig:muonium_decay>

Although the invisible decay still hasn't been observed, Standard Model predictions suggest the process would have a branching ratio $"Br"(M arrow nu_e overline(nu)_mu ) = 6.6 times 10^(-12)$ #cite(<Gninenko_2013>). The muonium preferably ($approx 100%$) decays into $e^+ e^- nu_e overline(nu)_mu$. The decay time is similar to the free anti-muon decay, but gets some corrections due to the interaction of the two particles. As discussed by _Czarnecki et al._ #cite(<Czarnecki_2000>), the leading effects, caused by the motion of the $mu^+$ in the rest frame of the muonium, generate a correction term

#block()[

#grid(columns: 3, column-gutter: 7em)[][ 
#eq[ $tau_M = tau_(mu) ( 1 + ( alpha^2 m_e^2 )/( 2 m_(mu)^2 ) )$, ]

][
#eq[ $( ( alpha^2 m_e^2 )/( 2 m_(mu)^2 ) ) approx 6 times 10^(-10)$. ]
]
  
]

Since the correction is really small, we will not consider it, and simply take $tau_M = tau_(mu)$.





== Up-Down Asymmetry
<sec:up-down>

Atmospheric muons are mainly produced from a two body decay of charged kaons and pions, as already mentioned in #ref(<sec:atm_mu>). Both those mesons are spinless particles, so the final state has to be a singlet state of spin. In the meson's rest frame, this means that the muon and the neutrino must have same helicity (opposite spin direction). In SM, neutrino are massless, so $nu$ must be left-handed and $overline(nu)$ must be right-handed. Therefore $mu^-$ must be produced right-handed, while $mu^+$ must be produced left-handed. But, since $pi$ and $k$ are highly energetic, the products of the decay will receive a Lorentz boost, and helicity is not Lorentz invariant. This means that is possible to see at sea level some muons with the "wrong" polarization.



Due to the V-A structure of the weak coupling, there is a correlation between the direction of the produced $e^plus.minus$ and the spin orientation of the $mu^plus.minus$, with a differential decay width:

$
(d^2 Gamma_plus.minus)/(d x  d Omega) = ( G_F^2 m_mu^5 )/( 192 pi^3 ) x^2 [ ( 3 - 2 x  ) plus.minus P_mu ( 2 x - 1 ) cos theta  ]
$

with $G_F approx (1.166 3787 plus.minus 0.000 0006) times 10^(-5) "GeV"^(-2)$ Fermi coupling, $m_mu approx (105.6583755 plus.minus 0.0000023) "MeV" $ mass of the muon, $x = ( 2 E_e )/( m_mu )$ energy fraction of the $e^plus.minus$, $theta$ angle between $mu^plus.minus$ spin direction and direction of the $e^plus.minus$ momentum and  $P_mu$ polarization of the $mu^plus.minus$, that, for an energy range of cosmic muons $E = (0.75 - 1.17)$ GeV, is $P_mu = -0.33 plus.minus 0.04$ #cite(<PhysRevD.4.17>). By integrating over $x = [0,1]$ to consider all possible energy fractions, we obtain:

$
(d Gamma_plus.minus)/(d cos theta) = Gamma_mu/( 2 ) [ 1 plus.minus A' cos theta  ]
$

with $A' = 1/3 P_mu xi $  integral asymmetry #cite(<FETSCHER1986102>), and $xi =1$ is one of the Michel parameters, that describe the phase space distribution of charged leptons decays into lighter leptons. Now we can integrate over $theta$, in order to separate the upward decays and the downward ones. Since, in the lab-frame, $mu^-$ are mainly right-handed, the electron goes upward for $theta = [ pi , pi/2]$. Meanwhile, since $mu^+$ are mainly left-handed, the positron goes upward for $theta = [ 0 , pi/2]$. This means that upward $U(t)$ and downward $D(t)$ decays will follow these relations

$
U(t) = U_0 ( 1 + A'/2 ) e^(-t/tau_mu)
$

$
D(t) = D_0 ( 1 - A'/2 ) e^(-t/tau_mu)
$



obtained assuming no depolarization effects or background events.

Now we can define the up-down asymmetry as

$
A = ( U(t) - D(t) )/( U(t) + D(t) ) = ( (U_0 - D_0) + A'/2 ( U_0 + D_0 ) )/( (U_0 + D_0) + A'/2 ( U_0 - D_0 ) )
$<eq:asymm>

If $U_0 = D_0$, we would obtain $A = A'/2 $. We can also notice that $A'/2 = 1/6 P_mu xi = -0.055 pm 0.007$ is a really small factor. Therefore, we are able to simplify @eq:asymm, grouping $(U_0 + D_0)$, obtaining

$
A  = ( (U_0 - D_0) + A'/2 ( U_0 + D_0 ) )/( (U_0 + D_0) + A'/2 ( U_0 - D_0 ) ) = ( (U_0 - D_0)/( U_0 + D_0 ) + A'/2  )/( 1 + A'/2 ( U_0 - D_0 )/( U_0 + D_0 ) ) approx (U_0 - D_0)/( U_0 + D_0 ) + A'/2 
$



In order to measure this asymmetry, one could put a magnetic field $B$ with a component orthogonal to the spin direction. By doing so, the spin will precede around the magnetic field axis, changing its direction. This process follows the Larmor precession, which tells us the spin will precede around the $B$ direction with a frequency:

$
omega_mu = - ( e g B )/( 2 m_mu )
$

with $e$ electric charge and $g approx 2$ gyromagnetic factor (neglecting corrections above tree-level). This effect makes the polarization time dependent with a periodic law, obtaining  $A' (t) = 1/3 P_mu xi cos ( omega_mu t )$. This means that the total asymmetry with magnetic field will be

$
A_(f i e l d)  approx (U_0 - D_0)/( U_0 + D_0 ) + (A'(t))/2 
$

Taking the difference of the 2 cases (with and without field) isolates the time dependent term, giving

$
A_(f i e l d) - A  = (A'(t))/2  - (A')/2 = 1/6 P_mu xi( cos ( omega_mu t ) - 1)
$<eq:parity_violation>



//== Scintillation mechanism

//for both muons and electrons

//what about e+? e+ e- annihilation?



//e- lost in the alluminum? no because e- has 30-50 mev, that's enough to escape allumium if not emitted parallel to the Al block (would not be revealed) 



//see particle 1 file for muon part