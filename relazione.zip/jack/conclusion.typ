#import "../preamble.typ": *
#import "@preview/subpar:0.2.2"

= Conclusions

With this experiment we were able to obtain decay time values of the muon in the $3$ studied materials compatible with the expected value, calculated in #ref(<sec:mu_interaction>). For vacuum measurement we obtained a $tau_(v o i d) = ( 2.193 pm 0.011 ) mu $s, that gives us a p-value $p = 71.72%$. For salt measurements we obtained $tau_(N a C l) = ( 700 pm 75) $ns, giving a p-value $p = 94.15%$. Finally, for aluminum we found $tau_(A l) = ( 870 pm 84) $ns, obtaining a p-value $p = 98.06%$.

Subsequently we changed our setup in order to have a magnetic field, and measure the up-down asymmetry as a function of the time. We are able to reject the Parity conservation hypothesis with a $98.06%$ C.L.. As further confirmation, we obtained a value of the pulsation $ omega = (1.16 pm 0.26) (r a d)/(mu s)$ , that is compatible with the expected value obtained known the intensity of the magnetic field, with a p-value $p = 95.33 %$.
Therefore we can confirm the presence of Parity violation.



//With the results obtained in the vacuum measurements, #rem[solo vacuum, o anche altri?], we could also give a rough estimate of the stopped muons mean energy. Given a measured rate of muon that decayed in our setup, for which we were able to observe an electron, and given the differential atmospheric muon flux discussed by  _Rastin_ #ref(<BCRastin_1984>), we can reconstruct an estimate of the muons energy range. We measured $N = $ events, in an experiment time window of $Delta t= (  pm  ) s$, from which we are able to obtain the measured rate $R^(o b s)_mu = (  pm  )(mu)/(s)$.

//First, we have to quantify how many electrons (produced from a muon decay) are collected due to solid angle. To do so, we take the geometry of our setup (dimension and distances of the scintillators) and integrate the electron angle distribution over the solid angle covered, starting from the central scintillator. 

//Then, we have to consider that the measured muons used for the interpolation, are in a limited time window.

