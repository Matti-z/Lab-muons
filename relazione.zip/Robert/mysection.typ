#import "../preamble.typ": *
= Instrumentation and Modular Electronics 

== Experimental Methodology and Workflow Architecture 

In order to transform raw physical interactions into reliable datasets we used the so-called "modular" approach: all acquisition process is mediated by many different components and each of them has its own purpose. So, rather than treating an acquisition setup as a rigid single instrument, we built our setup upon standard modular electronics that we arranged together. 
// This approach decouples individual signal processing tasks—such as amplification, discrimination, logical filtering, and digitization—into discrete units. 

// Our experiment has used the following model in order to be consistent, stable with the data collection and to use the "modular" approach through four fundamental phases:

This "modular" approach requires 4 steps to be able to collect reliable data: 

// #align(center)[
//   #block(
//     fill: rgb("f8f9fa"),
//     inset: 12pt,
//     radius: 6pt,
//     stroke: 0.5pt + rgb("e0e0e0"),
//     [
//       #set text(size: 10pt, weight: "bold")
//       Design & Assembly 
//       #sym.arrow.r
//       Characterization
//       #sym.arrow.r
//       System Integration
//       #sym.arrow.r
//       Data Production
//     ]
//   )
// ]

+ *Design and Functional Assembly*: Conceptualizing the signal path logic and physically staging the individual hardware modules within the crate. This is influenced by the available and functioning modules we had access to and our choices of what was more important for us (as will be discussed in @chap:elec_circ). // framework.
+  *Component Characterization*: Separately testing and validating each hardware component to check if each of them works as we would expect.
+ *System Calibration and Integration*: Combining the different modules into an interconnected, synchronized chain. Tuning thresholds, time delays, cables, exc. so that an initial signal can go through all the chain and give a resulting signal. This step also verify what in step 1. was theorized.
+ *Data Acquisition*: Launching the data collection and digitization for offline physical analysis.

This approach is very efficient in pursuing troubleshooting for each module that can lead to instrument dependencies and electronic anomalies, which can be systematically identify and correct.


== Experimental Infrastructure and Auxiliary Equipment

The experimental setup follows the *Nuclear Instrumentation Modules (NIM)* standard, using a dedicated crate to house and power the modular electronics. This crate provides the essential high-stability power rails ($plus.minus$ 6 V, $plus.minus$ 12 V, $plus.minus$ 24 V) and ensures a common grounding scheme. This configuration allows the minimization of the electronic noise by preventing ground loops.

The following precision laboratory instruments have been used to test all the electronic modules to obtain a stable and reliable acquisition:

#list(
  [*Tabor 8020 Pulse Generator (20 MHz)* served as the primary signal source for module characterization, providing reproducible pulses with adjustable parameters to simulate real detector events.],
  [*Tektronix TDS 2014B Oscilloscope (100 MHz, 1 GS/s)* ],
  // [*Calibrated RG-58 Coaxial Delay Cables ($50 thin Omega$)* were employed to shift signals by $2$ to $16$ ns. ],
  [*Multimeter Fluke 115 True RMS*  ] 
)

== Data Acquisition System and NIM Modules

The signal processing chain is designed to transform analog pulses into calibrated logic signals for real-time coincidence in order then to be processed and digitalized. 
The workflow is built by a suite of NIM-standard modules, which handle everything from signal replication to temporal logic. 
The instrumentation used is organized as follows:

#figure(
  block(width: 100%, align(left)[
    - *Discriminator Mod. N 96 (CAEN)*: Converts negative analog signals into standardized NIM logic pulses based on a tunable voltage threshold, serving as the primary trigger source.
    - *Octal Fan-Out Mod. 430 (LeCroy)*: An 8-channel distribution module used to replicate logic signals across various branches of the acquisition chain.
    - *Logic Unit Mod. N405 (CAEN)*: A programmable 4-channel unit used to perform Boolean operations (AND, OR, XOR).
    -  *Dual Timer N93B (CAEN):* 
      This module generates logic gate signals of adjustable duration upon receiving an input trigger, allowing for precise control over the coincidence window and gate width used in the acquisition chain.
    - *Dual Delay Module:* 
      This module provides accurate fine-tuning of the temporal alignment of signals, compensating for differences in cable lengths and propagation delays to ensure perfect synchronization between different channels.
    - *Counter Mod. N1145 (CAEN)*: Used for real-time monitoring of event rates and total counts, providing an immediate visual check of the experimental flux. Mostly used during the "testing" part of the experiment.
    - *Digitizer DT5720B (CAEN)*: A 12-bit ADC with a 250 MS/s sampling rate, performing digital charge integration and waveform reconstruction for offline analysis.
    - *Power Systems*: A Programmable Power Supply and a High Voltage (HV) Power Supply providing the stable bias voltages required for the detectors and the high-stability current for the NIM crate rails.
  ]),
  caption: none,
  kind: "list",
  supplement: none
)


== Logic Verification and Signal Distribution

The acquisition chain was initially tested to ensure the correct distribution of signals and proper synchronization across all timing branches.
During this phase we proceeded in testing and characterizing each of the modules in order to ensure the proper functioning and performance. 
// In the dedicated chapter we will discuss in detail the functioning of all of the signal chain components. #rem[reference to chapter]
The first module we tested was #strong[LeCroy 430 Octal Fan-Out]: we fed the logic NIM signals into the module to characterize it and to verify its preservation of fast rise times ($< 2$ ns). 

During the testing/troubleshooting phase we have tested all of the channels of the module. The results of the test have, as shown in @fig_oscillogram, a constant delay of 5 ns overall channels and a very low distortion of the input signal. 

To test the counter #strong[CAEN Mod. N1145] we used the following technique: knowing the frequency of a periodic signal generated by the pulse generator and setting a fixed acquisition time, it was possible to check the reliability of the counts displayed by the counter. All the channels of this instrument showed excellent behavior.

#figure(
  image("oscillogramma_fig_size_15_6.pdf", width: 15cm, height: 6cm, fit: "cover"),
  caption: [Oscilloscope trace testing Fan-Out module.],
  supplement: [Figure],
) <fig_oscillogram>

== Characterization of the Discriminator Mod. N96
<sec:discriminator>
Prior to the selection of the current module, the *CAEN Mod. N417* was initially considered; however, it resulted unsuitable for the experimental requirements due to significant hardware degradation and stability issues. In trying to test the module, several channels resulted damaged, including compromised adjustment screws that hindered precise calibration, and the threshold levels proved to be highly unstable over time. In addition, the N417 module failed to meet the dynamic range requirements of the experiment, as its maximum threshold was insufficient compared to the 250 mV signals targeted for rejection. Therefore, the *CAEN N96* was adopted to provide the necessary mechanical reliability and threshold stability.

A fundamental stage of the characterization for this module involved the linearity calibration of its central channels (CH4 to CH7, the ones we used). In fact, although all the channels have been tested, only the channels 4 trough 7 were reliable because the other channels we observed several problems, such as compromised adjustments screws and stability issues. This process was essential to establish the exact relationship between the manual potentiometer settings ($V_(t h)$) and the actual minimum input amplitude ($V_(i n)$) required to fire the discriminator. The experimental setup used the *Tabor 8020* to generate negative square pulses, which were split via a Fan-Out: one branch was sent to the oscilloscope for amplitude monitoring, while the other was fed into the *N96* discriminator. Thresholds were swept from $-50$ mV to $-225$ mV and measured with a precision multimeter. To account for mechanical hysteresis and ensure consistency, a "unidirectional approach" was adopted: we set each target threshold reaching it from a lower value to an higher one.

The resulting data were modeled using the following linear regression:

#math.equation(block: true, $ V_(i n) = a dot V_(t h) + b $)



//the instrumental uncertainty, estimated at $2$ mV, based on the oscilloscope's vertical resolution.

In order to estimate the errors, we measured the oscillation of the set threshold. 

We measured an oscillation of $Delta V_(t h) approx 2$ mV for the channels 4, 5, 7 and a $Delta V_(t h) approx 3$ mV for channel 6, therefore for the statistical analysis we have modeled the error with an uniform distribution in which $sigma$= 3mV is applied for channel 6 and $sigma$= 2mV for the remaining channels. 


#figure(
  image("Calibration_Plot_N96 (2).pdf", width: 110%),
  caption: [Linear regression of the N96 Discriminator threshold calibration for channels CH4-CH7.],
)


To evaluate the goodness-of-fit beyond the reduced Chi-squared ($tilde chi^2_nu$), the corresponding $p$-values were computed using the cumulative Chi-squared distribution function with $nu = N - k$ degrees of freedom, where $N$ is the number of experimental data points and $k = 2$ represents the free parameters of the linear regression (slope and intercept).



#figure(
  table(
    columns: (auto, auto, auto, auto, auto, auto, auto),
    align: (left, right, right, right, right, right, right),
    stroke: 0.5pt + luma(120),
    fill: (x, y) => if y == 0 { luma(240) } else { none },
    
    table.header(
      [*Channel*], [*$a$* (Slope)], [*$sigma_a$*], [*$b$* (Intercept)], [*$sigma_b$*], [*$tilde(chi)^2_nu$*], [*$p$-value*]
    ),
    
    [CH4], [1.110], [0.023], [-7.66], [3.36], [1.53], [0.18],
    [CH5], [1.042], [0.021], [23.08], [4.09], [2.14], [0.07],
    [CH6], [1.055], [0.053], [7.99],  [8.98], [1.70], [0.13],
    [CH7], [0.978], [0.026], [17.64], [4.43], [2.01], [0.09],

    table.footer(
      table.cell(
        colspan: 7, 
        align: left, 
        emph[Note: All voltage measurements ($b, sigma_b$) are expressed in mV. Input voltage uncertainty $sigma_(V_"in") = 2 text("mV")$ for CH4, CH5, CH7 and $sigma_(V_"in") = 3 text("mV")$ for CH6.]
      )
    )
  ),
  caption: [Fit parameters, uncertainties, reduced Chi-squared, and $p$-values for the N96 discriminator channels.],
  supplement: [Table],
) <tab_n96>

To evaluate the goodness-of-fit beyond the reduced Chi-squared ($tilde chi^2_nu$), the corresponding $p$-values were computed using the cumulative Chi-squared distribution function with $nu = N - k$ degrees of freedom, where $N$ is the number of experimental data points and $k = 2$ represents the free parameters of the linear regression (slope and intercept).

As reported in @tab_n96, all discriminator channels exhibit reduced Chi-squared values close to unity, ranging from $1.53$ to $2.14$. The associated $p$-values remain above the standard statistical significance threshold ($\ alpha = 0.05$), confirming that the linear model properly describes the response of the N96 discriminator and that the assigned experimental uncertainties $sigma_(V_"in")$ are realistic and well-estimated.

The $p$-value represents the probability of obtaining a Chi-squared statistic at least as extreme as the observed one, under the null hypothesis that the linear response model is correct. Since all calculated $p$-values exceed $0.05$, there is no statistical evidence to reject the null hypothesis, demonstrating good agreement between the linear calibration model and the experimental measurements across all active channels.

The analysis revealed slopes ($a$) near unity, with slight deviations ($0.978$ to $1.110$) reflecting internal gain factors specific to each channel. These values, alongside the intercepts ($b$), serve as calibration constants to accurately map physical thresholds during data acquisition. 

Notably, CH4 exhibited non-linear saturation for thresholds exceeding $200$ mV, causing the operational range to be strictly limited.
//therefore, the operational range was strictly limited to the verified linear region. #rem[specificare quali canali abbiamo usato, qui ci sono 4 canali, ma in teoria ne usiamo solo 3 (?)] 
//Therefore, since only 3 channels were needed, we used CH5, CH6 and CH7.

== Characterization of the Dual Timer Mod. N93B

To verify the gate-generation capabilities and the temporal precision of the CAEN N93B Dual Timer, we performed an overlap analysis using two decoupled channels monitored via the oscilloscope. A master logic pulse from the generator was split: the first branch was routed directly to Channel 1 (oscilloscope) to act as the reference trigger, while the second branch was used to trigger the N93B Dual Timer, with its output monitored on Channel 2 (oscilloscope).

Both channels exhibit stable NIM logic levels transitioning from a baseline of $0$ V down to approximately $-0.85$ V. The dual timer introduced a clean, programmable propagation delay of $18$ ns relative to the reference signal's falling edge at $t = 0$ ns. 

The testing of this module is important in order to maintain a good defined gate window in order to have reliability in the chain acquisition. 

To map the response of the timer channels, a master trigger pulse was fed into the input, and the resulting output logic pulse durations were systematically measured across all coarse range selector positions using the oscilloscope. The calibration results for the four output channels (CH1–CH2) for each timer are summarized in @tbl_dual_timer_calibration.

#figure(
  table(
    columns: (auto, auto, auto, auto, auto),
    align: (left, right, right, right, right),
    stroke: 0.5pt + luma(120),
    fill: (x, y) => if y == 0 { luma(240) } else { none },
    table.header(
      [*Nominal Setting*], [*Timer 1 (CH1)*], [*Timer 1 (CH2)*], [*Timer 2 (CH1)*], [*Timer 2 (CH2)*]
    ),
    [50 ns],   [50 ns],   [50 ns],   [70 ns],   [3 ns],
    [200 ns],  [138 ns],  [148 ns],  [192 ns],  [50 ns],
    [1 $mu$s], [720 ns],  [800 ns],  [1.9 $mu$s], [60 ns],
    [10 $mu$s], [6.4 $mu$s], [6.6 $mu$s], [20 $mu$s], [50 ns],
    [100 $mu$s], [24 $mu$s], [30 $mu$s], [163 $mu$s], [50 ns],
    [1 ms],    [56 $mu$s], [76 $mu$s], [1.5 ms],  [50 ns],
    [10 ms],   [620 $mu$s], [1.4 ms],  [15 ms],   [50 ns],
    [100 ms],  [7 ms],    [8 ms],    [175 ms],  [50 ns],
    [1 s],     [49 ms],   [127 ms],  [2 s],     [50 ns],
    [10 s],    [—],       [—],       [—],       [50 ns],

    // Footer note matching reference style
    table.footer(
      table.cell(colspan: 5, align: left, emph[Note: Measured output pulse widths correspond to discrete coarse knob selector positions on the CAEN N93B module.])
    )
  ),
  caption: [Measured output pulse widths for each coarse knob position on the CAEN Dual Timer Mod. N93B across all four output channels (CH1–CH4).],
  supplement: [Table],
) <tbl_dual_timer_calibration>

As detailed in @tbl_dual_timer_calibration, channels CH1, CH2 of timer 1 and CH1 of timer 2 scale monotonically with the rotary selector position, providing broad gate-width coverage from $50 thin "ns"$ up to full seconds. In contrast, Channel 2 (CH2) of the timer 2 remains fixed at a narrow, fast pulse width ($ tilde 50 thin "ns"$) across higher switch positions, effectively operating as an auxiliary prompt logic output. Therefore we have chosen to use only the timer 1 because it had both channel correctly functioning.  


== Characterization of the Logic Unit Mod. N405

This module has been tested in order to verify that the minimum temporal synchronization window for a logic operation such as AND or OR had a fixed value to guarantee overlapping of signals. In this prospective a timing overlap test has been conducted. 

The procedure involved generating identical negative NIM pulses, which were split and routed through physical passive delay stages to introduce a controlled relative time shift. These time-stamped logic pulses were then fed into the input channels of the N405 unit. By progressively adjusting the delay lines, the overlap width between the signals was incrementally varied while the logic unit's output was continuously monitored.

#figure(
  image("logicunit.pdf", width: 80%),
  caption:  [Oscilloscope screenshot displaying the coincidence window validation on the CAEN N405 Logic Unit. ],
) <fig_logic_unit_coincidence>

Using the oscilloscope's temporal cursors, the overlap between the falling edge of the trailing signal and the rising edge of the leading signal was measured to be exactly $Delta t = 6 thin "ns"$. The test has been conducted in several stages and all confirmed that the Mod. N405 stably registers this $6 thin "ns"$ overlap without generating transient logic state anomalies or spurious "glitch" pulses. The edge case maximum are 6 $"ns"$, meaning that with a 50 ns signal window, a 6 ns of overlap and above results in accepting the event.
This shape of the sharp edge temporal waveform in a very good index that the logic unit is capable of executing high-rate Boolean operations without drift, fulfilling a critical requirement for suppressing random background coincidences during the final data acquisition run.

== Characterization of Dual Delay Module

To verify the precise passive phase-shifting capabilities of the Dual Delay module, we characterized it using the oscilloscope. The primary aim of this test was to accurately quantify the hardware-induced temporal shift and evaluate edge degradation or amplitude attenuation across the delay line. 

We fed a master logic pulse into a Fan-In/Fan-Out module to duplicate the signal into two identical branches: a reference branch routed directly to Channel 1 of the oscilloscope, and a second branch passed through the passive Dual Delay module under test before being monitored on Channel 4. 

Direct observation on the oscilloscope confirmed that the set delay value matched the measured time shift. Furthermore, a side-by-side comparison of the waveforms verified that the input and output signals were similar in profile: the delayed pulse preserved its sharp, sub-nanosecond rise time and full NIM voltage amplitude without suffering from edge slurring, distortion, or attenuation. This transparent propagation confirms the module's reliability for fine-tuning signal alignment across independent detection channels prior to coincidence logic processing.


== Data Acquisition and Waveform Digitization

The final stage of the acquisition chain is the #strong[CAEN DT5720B Digitizer], a 12-bit ADC operating at a 250 MS/s sampling rate. The primary objective of the digitizer calibration was to establish a precise mapping between raw ADC counts and physical voltage levels ($V$). Given the 12-bit resolution distributed over a $2$ Vpp dynamic range, the theoretical conversion factor is determined by:

#math.equation(block: true, $ Delta V = (2 thin "V") / 2^(12) approx 0.488 thin "mV/count" $)

Data acquisition and visualization parameters were managed via the CAENScope software interface, where the acquisition window was configured with a record length of 2048 sampling bins per event. At a clock speed of 250 MS/s (corresponding to a 4 ns time step per bin), this arrangement yielded a comprehensive observation window of 8.192 $mu$s, providing more than sufficient temporal margin to capture the entire evolution of the pulse alongside its surrounding baseline.

Before starting with the data collection, the software has been used and tested in different configurations in order to understand its behavior in terms of noise and offsets.
