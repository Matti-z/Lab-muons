#import "../preamble.typ": *
#import "@preview/subpar:0.2.2"

#align(center)[
  #set par(justify: true)
  
#set heading(numbering: none, outlined: false)
= Abstract

The measurement of the muon lifetime and decay dynamics provides fundamental experimental evidence for Special Relativity and the Weak Interaction.
This experiment aims to observe muon decay and demonstrate parity symmetry violation in weak decays. 
A modular experimental setup was designed, tested, and assembled, consisting of three plastic scintillators coupled to Photomultiplier Tubes (PMTs), a modular electronic signal-processing chain, a digital data acquisition system (digitizer), and a solenoid producing a uniform magnetic field. 
To isolate valid muon decay events, a coincidence/veto trigger system was implemented to detect the energy deposited by decay electrons within the scintillators in different materials (air and salt). 
The setup successfully demonstrated parity violation by observing the asymmetric angular distribution of decay electrons and spin precession of decaying muons as a function of the applied magnetic field.

Everything that is talked about is accessible on GitHub #cite(<github_repo>)

]