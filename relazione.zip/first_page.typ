// #import "../preamble.typ": *
#import "@preview/subpar:0.2.2"

#v(2em)
#title()

// spazio per autori


#figure(image("logoist_3.jpg", width: 40%), outlined: false, numbering: none)

#v(5em)
#align(center)[
Authors: 
#context {
  let authors = (
    (name: document.author.at(0), id: "896999", email: "a.boldetti@campus.unimib.it"),
    (name: document.author.at(1), id: "898407", email: "g.casanova4@campus.unimib.it"),
    (name: document.author.at(2), id: "887088", email: "r.friets@campus.unimib.it"),
    (name: document.author.at(3), id: "896811", email: "m.zorloni6@campus.unimib.it"),
  )


figure(table(
  columns: 3,
  stroke: none,
  [], [*ID*], [*Email*],
  ..authors.map(author => (author.name, author.id, author.email)).flatten(),
), outlined: false, numbering: none)
}
#v(7em)
#datetime.today().display()
]

// Versione provvisoria – aggiornato il 



#pagebreak()