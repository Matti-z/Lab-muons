// FILE PREAMBOLO
// In questo file sono definite alcune impostazioni, principalmente matematiche, che potrebbero essere utili durante la scrittura.
// Va importato in ogni documento.

// ==== IMPORT GENERALI ====

#import "@preview/physica:0.9.7": *
#import "@preview/wicked:0.1.1": wick as wickB
#import "@preview/fletcher:0.5.8" as fletcher: diagram, node, edge, 
#import fletcher: shapes 
#import fletcher.shapes: ellipse




// sovrascrivo la posizione di default della contrazione a top
#let wick(..args) = wickB(pos: top, ..args)

// ==== MACRO UTILI ====

#let d4p = $(d^4 p) / (2 pi)^4$ // ## DEPRECATO ## usare il metodo nuovo poco sotto
#let d3(p) = $(dif^3 vectorarrow(#p)) / (2 pi)^3$
#let d4(p) = $(dif^4 #p) / (2 pi)^4$
#let lag = $scr(L)$
#let phia = $phi.alt$
#let psibar = $overline(psi)$
#let pm = $plus.minus$
#let pdslash = $cancel(partial)$
#let Dslash = $cancel(D)$ 

#let bra(v) = $⟨#v|$
#let ket(v) = $|#v⟩$
#let braket(v, w) = $⟨#v|#w⟩$
#let expval(op) = $⟨#op⟩$

#let vet(v) = $vectorarrow(#v)$
//#let dv(expr, var) = $∂#expr / ∂#var$
#let dvt(expr, var) = $d#expr / d#var$
#let exp(x) = $e^(#x)$

#let refequiv(body) = stack(
  "=",
  text(size: 8pt)[#body]
) //scrivere la referenza sotto agli uguali nelle formule (magari c'è mdoo migliore per farlo). e.g: refequiv(#text[#ref(<eq:s_Dspinor_transf>)])

// ==== ALTRE DEFINIZIONI ====

// Macro TODO per segnare cose da completare (visibile, ma facile da cercare)
#let rem(t) = text(red, size: 13pt)[#upper(highlight(t))] 

#let todo(body) = block[
  #set text(fill: rgb("#b00020"), 
            weight: "bold", 
            size: 18pt,
            )
  TODO: #body
]

#let eq(body) = {
  math.equation.with(
    block: true,
    numbering: none,
  )(body)
}

#let cap(t) = block[
  #set text(size: 16pt)
  #v(1em)
  *#t* \
]






// #let in-outline = state("in-outline", false)
// #show outline: it => {
//   in-outline.update(true)
//   it
//   in-outline.update(false)
// }

// #let flex-caption(long, short) = context if in-outline.get() { short } else { long }

// // And this is in the document.
// #outline(title: [Figures], target: figure)

// #figure(
//   rect(),
//   caption: flex-caption(
//     [This is my long caption text in the document.],
//     [This is short],
//   )
// )