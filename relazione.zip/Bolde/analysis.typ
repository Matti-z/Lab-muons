#import "../preamble.typ": *
#set text(region: "GB") // change language of the file

#let w=68.2%

= Data Analysis
<sec:data_anal>

The data analysis has been made using iMinuit, we used poissonian errors for each bin and we minimised the negative log likelihood. All analysis and more is available on github #cite(<github_repo>) 

== Initial issues
We found three issues with this method:
+ what to use to quantify the goodness of the fit
+ how many bins would each histogram need
+ the model to choose


=== Chi square as estimator of the goodness of the fit
Although data inside each bins are distributed as a poissonian distribution, with enough data we can fall back under the hypothesis of data distributed as a normal distribution.
If we assume this hypothesis as valid, what we found is a minimum number of events per bin to approximate the poissonian distribution to a normal distribution and, if we respect this constraint in each bin, we can say that $tilde(chi)^2$ is a good estimator of the goodness of the fit, similarly to what happens when using Least Squares method. Therefore we decided to use $tilde(chi)^2$ as an estimator of the goodness of the fit.


=== Model of the interpolation
We were uncertain about whether to consider an uniform noise background or to interpolate without it. By letting the frequency between exponential distributed points and uniform distributed points, we found that the noise frequency is around 5%. Although it might be small, it has a relevant impact in the error estimation of the variable: if we consider an uniform background, both relative errors and $tilde(chi)^2$ decrease, therefore we decided to keep it.


=== Bins choice
To choose how many bins to give each histogram, we used $tilde(chi)^2$ to see how the interpolation behaved at different bins width. Therefore we chose the number of bins that minimises the $tilde(chi)^2$. We found it generally to be between $60$ and $100$ bins but the specific number changes from dataset to dataset. 

== Vacuum measurements
As said in @chap:muons_prop, if the muons decay in the scintillator, a very light difference in the time characteristic is present. This difference cannot be seen in our data sample since it is dominated by statistical uncertainties.
We therefore compare the result of the fit to the decay time of the muon in vacuum.


As fit function we use a combination of exponential and a uniform background, normalised  on the dataset, as follows:

$
f_{"vacuum"}(t ; f_("exp"), tau) = N [ f_("exp") dot p_("exp")(t , tau) + ( 1 - f_("exp") )  p_("uniform") ]
$<eq:vacuum_interp>

where $p_("exp")$ and $p_("uniform")$ are the CDF of exponential and uniform distributions limited to the range of the dataset and N is the total number of events.

Due to the presence of unexpected signals at the start of the trace, and due to edge effect at the end of the dataset, we decided to apply two cuts to the dataset. To choose the optimal position where those cuts have to be performed, we ran some interpolations varying the time interval in which we consider the data. From every fit, we took the $tilde(chi)^2$ and showed it in #ref(<fig:vacuum_cuts>).




#figure(
  image("figures/void_cuts.pdf", width: w),
  caption: [Vacuum analysis:\
            On top: Raw data collected and the data taken after the cuts. \
            On bottom: $tilde(chi)^2$ for different cuts at the edges of the histogram ],
)<fig:vacuum_cuts>



We can see how at the start and at the end of the dataset there are data that notably worsen the interpolation. We believe the signals in the very first $0.2 mu s$ are due mainly to Minerva's PMT fluctuations overimposed on muon's decay signals.The noise over $7.5 mu s$ is due to a small jitter in the end gate of the timer that therefore decrease the number of data acquired in that region and therefore decide to remove them. 

In order to choose the  number of bins $N$ to use, we calculated the $tilde(chi)^2$ of the dataset for different number of bins and chose the one that minimises it.



#figure(
  image("figures/void_bins.pdf", width: w),
  caption: [ Vacuum analysis: $tilde(chi)^2$ for different number of bins. ],
)<fig:vacuum_bins>



Since we don't see a clear pattern varying the number of bins, we decided to take 68 bins, for the range $[0.2 , 7.5] mu s $, causing every bin to have a $10 n s$ width. In #ref(<fig:vacuum_interp>) we show the final fit of the dataset, together with the percental deviation of the data from the interpolated function. #ref(<tab:vacuum_interp>) contains the fitted parameters of the free decay, with their errors.

#figure(
  image("figures/void_interp.pdf", width: w),
  caption: [Vacuum analysis:\ On top: The fitted dataset, and the resulting interpolation function.  \
            On bottom: Relative deviation of the data respect to the fit. ],
)<fig:vacuum_interp>

#figure(
  image("figures/void_components.pdf", width: w),
  caption: [Vacuum analysis: Simulated contributions of the vacuum dataset and real dataset],
)<fig:vacuum_components>

In the figure above we show how the sample are distributed according to the fitted parameters of the functions. The components of the plot are simulated but it gives a good idea of how frequent the data were part of each phenomena.





#figure(
  table(
  columns: (auto, auto, auto),
  align: (left, right, right),
  stroke: 0.5pt + luma(120),
  fill: (x, y) => if y == 0 { luma(240) } else { none },
  [*Parameter*], [*Value*], [*Uncertainty*],
  [$f_("void")$], [0.97], [0.010],
  [$tau_("void")$], [$2.193 mu s$], [$11 n s$],
),
  caption: [Vacuum fit parameters],
  supplement: [Table],
)<tab:vacuum_interp>



From the values in #ref(<tab:vacuum_interp>), and using the function in #ref(<eq:vacuum_interp>), we can derive the amplitude $A$ of the uniform background, and its error, obtaining $A = 1-f_("exp") = 0.033 plus.minus 0.010$. Although the uniform background noise is low, it is not compatible with zero, therefore is not negligible. 


In #ref(<fig:vacuum_tau>) we also show the Negative-Log-likelihood of the parameter $tau$, and the comparison with the expected value.


#figure(
  image("figures/void_tau.pdf", width: w),
  caption: [Vacuum analysis: Negative-LogLikelihood of the parameter $tau_"void"$ ],
)<fig:vacuum_tau>




As we can see, the expected value is below
$1 sigma$ distant from our measure, therefore is compatible.



As a further check for our setup, we looked at the up-down asymmetry of this dataset, defined as in #ref(<eq:asymm>). 


#figure(
  image("figures/void_skewness.pdf", width: w),
  caption: [ Vacuum analysis: Up-Down asymmetry ],
)<fig:vacuum_asym>

We can see in #ref(<fig:vacuum_asym>) how a relevant asymmetry in favour of the lower scintillator is present. This type of asymmetry will be present across all measurements and is most likely due to a miss-calibration of the scintillators.






== Decay time in salt

We changed our setup to accommodate salt in between Minerva and Partenope. This has brought a different behaviour to be studied: the decay of muons in salt due to the interaction with the nuclei. This interaction is way more frequent than in carbon and it creates a greater variation with respect to the mean lifetime of a muon (@sec:mu_interaction).

To study this behaviour, we modified the model used previously in #ref(<eq:vacuum_interp>). In particular, we switched the exponential CDF with a double exponential determined by another two parameters of the interpolation
$
f_("exp") dot p_("exp") = f_("void") space.med p_("exp")(t , tau_("void")) + f_("NaCl") space.med p_("exp")(t , tau_("NaCl"))
$<eq:salt_interp>

where $p_("exp")$ is the CDF of exponential distribution limited to the range of the dataset and the factor in front of the uniform CDF has transformed accordingly.

Similarly to what we did with vacuum measurements, we used $tilde(chi)^2$ to decide bin width and cuts to apply at the dataset. Since the setup is the same as before, here we expect to apply cuts in points similar to the ones in #ref(<fig:vacuum_cuts>).

#figure(
  image("figures/na_cuts.pdf", width: w),
  caption: [salt analysis:\ On top: Raw data collected and the data taken after the cuts. \
            On bottom: $tilde(chi)^2$ for different cuts at the edges of the histogram ],
)<fig:salt_cuts>

#figure(
  image("figures/na_bins.pdf", width: w),
  caption: [salt analysis: $tilde(chi)^2$ for different number of bins. ],
)<fig:salt_bins>


Following the same logic as the previous case, we opted for a bin width slightly larger with a number of bins of 64 and a bin width of $11.4 n s$ in the range $[0.2 , 8]mu s$.


#figure(
  image("figures/salt_interp.pdf", width: w),
  caption: [Salt analysis: \ On top: The fitted dataset, and the resulting interpolation function .  \
            On bottom: Relative deviation of the data respect to the fit. ],
)<fig:salt_interp>

#figure(
  image("figures/na_components.pdf", width: w),
  caption: [ Salt dataset: Simulated contributions of the salt dataset and real dataset],
)<fig:salt_components>

As we can see, here clearly a second exponential is present in addition to the noise background that we expect to be about constant in all the measures taken.


#figure(
  table(
  columns: (auto, auto, auto),
  align: (left, right, right),
  stroke: 0.5pt + luma(120),
  fill: (x, y) => if y == 0 { luma(240) } else { none },
  [*Parameter*], [*Value*], [*Uncertainty*],
  [$f_("void")$], [0.8452], [0.0217],
  [$f_("NaCl")$], [0.1016], [0.0156],
  [$tau_("void")$], [$2.193 mu s$], [$22.0 n s$],
  [$tau_("NaCl")$], [$700 n s$], [$75 n s$],
),
  caption: [Salt fit parameters],
  supplement: [Table],
)<tab:salt_interp>

In the interpolation we opted for fixing the components in common between the two  measurements. It being the the characteristic of the exponential for the decay of the muon with no interaction.
With this parameter fixed, we measure a mean lifetime of the muon in the salt compatible with the expected value that we assume known without error. And a frequency of the noise background similar to the previous case: $A = 1 - f_("void") - f_("NaCl") = 0.06 pm 0.02$

#figure(
  image("figures/na_tau.pdf", width: w),
  caption: [Salt analysis: Negative-LogLikelihood of the parameter $tau_"NaCl"$],
)<fig:salt_tau>

Moreover we kept checking whether the addition of material inside the setup broke the symmetry we found in the previous part.

#figure(
  image("figures/salt_skewness.pdf", width: w),
  caption: [Salt analysis: Up-Down asymmetry],
)<fig:salt_asym>

What we found is an asymmetry compatible to the one before.






== Decay time in aluminium
Lastly, we substitute salt with slabs of aluminium. This change, as said in @sec:mu_interaction, should return data close to the ones gathered in salt but with different frequency and lifetime since aluminium has a higher atomic number.


In this measurements we used the same fit function as in salt, as stated in #ref(<eq:salt_interp>)


Analogously to what has been done previously, we used $tilde(chi)^2$ to decide bin number (or bin size) and which cuts to apply.

#figure(
  image("figures/al_cuts.pdf", width: w),
  caption: [Aluminium analysis:\ On top: Raw data collected and the data taken after the cuts \
            On bottom: $tilde(chi)^2$ for different cuts at the edges of the histogram],
)<fig:al_cuts>

#figure(
  image("figures/al_bins.pdf", width: w),
  caption: [Aluminium analysis: $tilde(chi)^2$ for different number of bins ],
)<fig:al_bins>

This time, the shape of the dataset has notably changed and with that also the bin number.
We chose 78 bins for the range $[0.25, 8] mu s$ for a bin width of $10 n s$

In this case we delayed slightly the electron signal and this gave a huge improvement in the cutting zones. While in the bin width the range is close to the others with 78 bins.

#figure(
  image("figures/al_interp.pdf", width: w),
  caption: [Aluminium analysis:\ On top: The fitted dataset, and the resulting interpolation function @eq:salt_interp.  \
            On bottom: Relative deviation of the data respect to the fit. ],
)<fig:al_interp>

#figure(
  image("figures/al_components.pdf", width: w),
  caption: [Aluminium analysis: Simulated contributions of the aluminium dataset and real dataset],
)<fig:al_components>

As previously, a second exponential is present and the uniform distribution is around the same percentage


#figure(
  table(
  columns: (auto, auto, auto),
  align: (left, right, right),
  stroke: 0.5pt + luma(120),
  fill: (x, y) => if y == 0 { luma(240) } else { none },
  [*Parameter*], [*Value*], [*Uncertainty*],
  [$f_("void")$], [0.7864], [0.0337],
  [$f_("Al")$], [0.1785], [0.0262],
  [$tau_("void")$], [$2.193 mu s$], [$20 n s$],
  [$tau_("Al")$], [$870 n s$], [$84 n s$],
),
  caption: [Fit Parameters],
  supplement: [Table],
)<tab:al_interp>


Similarly to what done previously, we fixed the common factors between interpolation. Doing so we found a value of the lifetime of the muon when interact with the nuclei of aluminium that is compatible to what has been found in chapter @sec:mu_interaction

#figure(
  image("figures/al_tau.pdf", width: w),
  caption: [Aluminium analysis: Negative-LogLikelihood of the parameter $tau_"Al"$ ],
)<fig:al_tau>

The changes in the setup improve further the symmetry of the setup. In fact, in this dataset we are close to 5% asymmetry of the data taken.

#figure(
  image("figures/al_skewness.pdf", width: w),
  caption: [Aluminium dataset: Up-Down asymmetry],
)<fig:al_asym>

== Parity Violation

=== Setup
As discussed in section #ref(<sec:up-down>), in order to see the effects of parity violation with our setup we have to insert the middle scintillator (the one in which the particle decays) in a magnetic field such that the spin of the decaying particle precedes around the direction of the field. Because of mechanical and scheduling issues, we had to join another group that was doing the same experiment and to study parity violation with a different setup: from our previous experiments we only used Partenope scintillator. All the characterisation and tuning of the new electronic setup was done by the other group #cite(<muoni1>).

We setup the scintillator as done previously in @fig:setup_real_photo with Partenope in the middle inserted in the magnetic field and the two scintillator of the other group on top and bottom. This choice has been made to be neutral to different calibrations done by the two groups separately.


=== Calibration of the magnetic field generator
Before starting to take measurements, we need to study the solenoid and be sure that the magnetic field is linear according to Biot-Savar law.

#figure(
  image("figures/linearity.pdf", width: w),
  caption: [Intensity of field in 3 points of the coil given different currents ],
)<fig:parity_violation_linear>



Before the beginning of the measurements of the parity violation, we tested the uniformity and the stability of the magnetic field inside the solenoid with a magnetometer. Results are in @fig:mag_field_res.

#figure(caption: [Uniformity test results of magnetic field. The scale is in Gauss. All data are $pm 0.2 G$, \ left figure: $6A$ , right figure $4.5A$ ],
block()[
#grid(columns: 2, )[
  #image("figures/uniformity1.pdf")
  
][
  #image("figures/uniformity2.pdf") 
]
])<fig:mag_field_res>

As we can see, at high current values, a hole is present in the back of the solenoid. Therefore we limit ourselves to a current of 4.5A that shows no evident sign of non-uniformity.




=== Measurements with no magnetic field
Since neither of the two group has ever used this setup, we opted for a preliminary measure with the coil but without turning the magnetic field on. This will give us a confirmation of the behaviour of the setup and an initial measurement of the setup asymmetry that will be detracted from the real measurement.

We proceeded therefore in similar way to what has been done previously. Since the objective of the measurement is to check the proper functioning of the system and measure its asymmetry, we will neglect hypothesis testing and accurate measurement of the muon time characteristic.

We therefore proceeded to decide where to cut the dataset and the optimal bin width as before.

#figure(
  image("figures/nf_cuts.pdf", width: w),
  caption: [parity violation analysis:\ On top: Raw data collected and the data taken after the cuts. \
            On bottom: $tilde(chi)^2$ for different cuts at the edges of the histogram],
)<fig:nf_cuts>

#figure(
  image("figures/nf_bins.pdf", width: w),
  caption: [parity violation analysis: $tilde(chi)^2$ for different number of bins. ],
)<fig:nf_bins>

We see that the optimal number of bins is at 80 between the range $[0.3 , 8] mu s$ with a bin width of $10 n s$.

#figure(
  image("figures/nf_components.pdf", width: w),
  caption: [parity violation analysis: Simulated contributions of the asymmetry dataset and real dataset],
)<fig:nf_components>

We see how the uniform is less relevant than the other cases. This gives us reason to think that the uniform noise is mainly given by the presence of Minerva (the thin scintillator), assuming the behaviour of Giunone similar to the one of Partenope.



#figure(
  table(
  columns: (auto, auto, auto),
  align: (left, right, right),
  stroke: 0.5pt + luma(120),
  fill: (x, y) => if y == 0 { luma(240) } else { none },
  [*Parameter*], [*Value*], [*Uncertainty*],
  [$f_1$], [0.98], [0.01],
  [$tau_("void")$], [$2.095 mu s$], [$35 n s$],
),
  caption: [calibration fit parameters],
  supplement: [Table]
)


In this case we are unable to fix any factors since the setup is different.


#figure(
  image("figures/nf_skewness.pdf", width: w),
  caption: [parity violation analysis: Up-Down asymmetry],
)<fig:nf_asym>


Finally, we see how in this setup an initial asymmetry towards the bottom scintillator is present and therefore needs to be subtracted from the dataset with the magnetic field on.

=== Measurement with magnetic field

Turning on the magnetic field, we want to measure the variation of symmetry between the above and below scintillators. If we chose a bin number similar to the one used above, we wouldn't be able to see anything since the difference would be negligible with bins of that size. Therefore we opted for a number of bin of 7 to increase the visibility of the phenomena.

#figure(
  image("figures/nf_skewness2.pdf", width: w),
  caption: [parity violation analysis: new Up-Down asymmetry],
)<fig:nf7_asym>

We see how with 7 bins the asymmetry is about constant at 25%. We therefore subtract this asymmetry to the asymmetry of the dataset with magnetic field.

We already talked about the model to use in case of parity violation in @eq:parity_violation:
$
f_(p v) = A cos( omega t + phi) + c
$

While, in case of parity conservation, the model is a constant line:
$
f_(p c) = c
$

#figure(
  image("figures/parity_violation.pdf", width: w),
  caption: [ Data asymmetry with both models of parity violation and conservation ],
)<fig:parity_violation>

#figure(
  table(
  columns: (auto, auto, auto),
  align: (left, right, right),
  stroke: 0.5pt + luma(120),
  fill: (x, y) => if y == 0 { luma(240) } else { none },
  [*Parameter*], [*Value*], [*Uncertainty*],
  [A], [$2.4%$], [$0.9%$],
  [$phi$], [$0.6 space.med r a d$], [$1.1 space.med r a d$],
  [$omega$], [$1.16 space.med r a d$/$mu s$], [$0.26 space.med r a d$/$mu s$],
  [c], [$-6.2%$], [$0.94%$],
),
  caption: [Parity violation fit parameters],
  supplement: [Table],
)

#figure(
  table(
  columns: (auto, auto, auto),
  align: (left, right, right),
  stroke: 0.5pt + luma(120),
  fill: (x, y) => if y == 0 { luma(240) } else { none },
  [*Parameter*], [*Value*], [*Uncertainty*],
  [c], [$-5.6%$], [0.63%],
),
  caption: [Parity conservation fit parameters],
  supplement: [Table],
)

// As we can see, initially we are not able to determine whether either model is better to describe the dataset. 
// Therefore we use the likelihood-ratio test to quantify the probability of the models to describe our dataset.

In @fig:parity_violation, we see our dataset compared with the theoretical expectation of parity violation given by the Standard Model and both fits. To confirm the fact that our data show parity violation, we can use the _LogLikelihood-ratio_ test to do hypothesis testing.

#figure(
  image("figures/hypothesis_testing.pdf", width: w),
  caption: [ Parity violation: hypothesis testing using the log-likelihood ratio test ],
)<fig:hypothesis_testing>



We simulated data given the known errors of each point and generate the distribution of the likelihood ratio given the different models. What we found is depicted in @fig:hypothesis_testing: we see how our model can reject the null hypothesis with $98.06%$  probability and therefore we can say that we are able to detect parity violation in our data sample.

Moreover, since the fit rejects the null hypothesis so well, we can study its pulsation value in comparison to what is expected:

#figure(
  image("figures/pv_omega.pdf", width: w),
  caption: [ Parity violation: hypothesis testing using the log-likelihood ratio test ],
)<fig:omega>

We can see how the parameter space of the pulsation is not strictly symmetrical. Although this can seem an issue we can use the upper error to still calculate the goodness of our parameter estimate.




