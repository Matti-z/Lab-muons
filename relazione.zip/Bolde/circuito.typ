#import "../preamble.typ": *
#import "@preview/subpar:0.2.2"

#set text(region: "GB") // change language of the file


= Electrical setup 
<chap:elec_circ>
The setup we chose to minimise dead time and pileup probability is the following:

#figure(
  image("figures/circuit.pdf"),
  caption: [electronic setup graph],
)<fig:circuit>
#subpar.grid(
   columns: (2fr,2fr) ,
  figure(image("figures/circuito.jpg", width: 114%), caption: [circuit], ), 
  figure(image("figures/scintillatori.jpg", width: 86%), caption:[scintillator setup]),<fig:setup_real_photo>,
  caption:[our setup],
) 
This is the result of multiple iterations of possible circuits.
The final result can be divided into 3 components:

- Discriminator and Fan-In/Fan-Out
- Logic Unit, Delay unit and Dual Timer
- Digitizer

Discriminator and Fan-In/Fan-Out make out the initial part of the circuit. Their role is to take the analogical input from the PMTs, transform them into logical signals, duplicate them and then send them to the next steps.

The second section of the circuit has the role to compute the logic and manage the delays between logical inputs.
The Logical unit is divided in 3 identical sections.
The first one detects whether a particle has passed through one of the external scintillators and not in the other. It detects the electron after the decay of the muon.
The second one detects if a particle passed through the top and middle scintillator and not in the bottom one. It detects a muon that stops in the middle scintillator.
The third one combines the other two into a single one and orders them temporally: it doesn't accept an electron if a muon hasn't happened before in a time range dictated by the dual timer width.
In this section, the delay module has the utility of cancelling the delay caused by the dual timer initial stage and by fine tuning these two different windows we are able to not include the muon in the final results since if a signal returns true in the second section, then it will return true also in the first one.

Lastly, the digitizer has the role to transform the logical (or analogical) inputs into digital ones. It uses a trigger to start the data taking window. The window lenght is uniquely dictated by the buffer lenght since the frequency cannot be changed. Moreover the digitizer has the possibility to set the trigger to be in a specific part of the buffer: if we choose it to be at the end of the buffer, we will have it as last input of the trace.

This is exactly what we did: we used the third section of the logic unit (the one that tells us if an electron has been detected) as trigger and set the trigger position at the end of the buffer such that we were able to go "back in time" to look for the muon stopping inside the middle scintillator.

This has been the most efficient way to take data by optimizing the void trace percentage.

Since we were interested in measuring the asymmetry between the top and bottom scintillator, we also fed the digitizer the two outputs of the upper and lower scintillators such that we are able to distinguish where the electron landed.

== Minerva pulse issues
We soon noticed that Minerva was the worst of the three scintillator. This was due to its thickness being half of the other two but also due to a phenomena for which pulses coming from Minerva were correlated to spurious correlations in the range of $1 mu s$ with a gaussian distribution.

#figure(
  image("figures/minerva_timestamp.pdf"),
  caption: [Muon distribution with timestamp taken from only Minerva],
)<fig:minerva_timestamp>

This is most likely due to a malfunction in the PMT that at the firsts multiplication stages is instable and therefore lets out electrons that should not be accelerated.


#figure(
  image("figures/minerva_signal.pdf"),
  caption: [Example of the rebounce phenomena in Minerva],
)<fig:minerva_signal>

We fixed this issue by placing Minerva in between the two others: we willingly choose to have a thinner layer of scintillator material in which the muon can decay with the advantage of having a cleaner signal when it comes to detecting the electron.
Since we decided to use the electron as trigger, this resulted also in a decrease of the rates of empty traces 


== Time resolution and dead time
We chose to measure the time resolution of the setup by simulating an event with a wave generator.
Giving to the discriminator a strictly positive square wave with a width comparable to the signal observed and a low frequency to avoid pileup effect, we were able to delay the signal of the bottom scintillator to simulate both the muon decay and the electron release with only one impulse from the wave generator.

It is enough to simulate the electron energy release only in the bottom scintillator since the electronic chain is completely symmetrical.

#figure(
  image("figures/time_resolution.pdf"),
  caption: [Measured time resolution of the whole setup],
)<fig:tr>

The result is a distribution about uniform of width $12 n s pm 4n s$, the uncertainty is fully determined by the frequency of the digitizer. This tells us the minimum error that we can expect from our setup without considering the scintillators.

Another statistically relevant characteristics of the setup is the dead time. 
Since the setup used previously was not useful for an accurate measurement of the dead time, we opted for calculating this factor using actual data. This is easily done using actual data: if we express the impulse given by the muon stopping in the middle scintillator and we look for the closest electron signal, what we find is the exact measurement of the dead time of the setup

#figure(
  image("figures/dead_time.pdf", width: 12cm),
  caption: [zoom on an initial part of a dataset ],
)<fig:dead_time>


We can easily measure it given a dataset and it turns out to be: $76 n s pm 4 n s $ where the uncertainty of this value is again dominated by the frequency of the digitizer.

== Pileup probability

Given the dead time calculated previously and the fact that the apparatus is non paralyzable we are able to calculate the expected rate of our setup:
$
n = m/(1+m tau) 
$
where $m$ is the rate at which we measure events and $tau$ is the dead time of our apparatus.
Across all measurements done, we measured an average rate of: $m = 0.012 "muons"/s$ and a dead time of: $tau = 76 n s$.

We see that the expected rate $n$ is equal to our actual measured rate and therefore we have a pileup probability of $0%$.


