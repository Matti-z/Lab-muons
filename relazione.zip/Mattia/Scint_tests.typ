#import "../preamble.typ": *
#import "@preview/subpar:0.2.2"

= Scintillators


== Technical charateristics

This chapter details the physical and operational properties of the plastic scintillators used. These detectors, based on a Polyvinyltoluene (PVT) polymer base, are known for their high speed, excellent light yield, and versatility in high-energy physics applications.

The scintillators used (specifically the EJ-200 / BC-408 and EJ-204 / BC-404 series) are organic plastic scintillators. Their operation is based on the excitation of the polymer base by ionizing radiation, followed by the emission of fluorescence photons. Polyvinyltoluene provide high light conversion efficiency. 
// Wavelength of Maximum Emission: The emission spectrum is centered in the blue region, typically between 400 nm and 425 nm. This wavelength is chosen to match the peak quantum efficiency of standard bi-alkali PMTs.
The primary advantage of plastic scintillators is their fast response time, making them suitable for high-count rate experiments:
- Rise Time ($t_r$): Extremely short, typically between 0.5 ns and 0.9 ns.
- Decay Time ($tau$): Ranges from 1.8 ns to 2.1 ns (for general-purpose models like BC-408/EJ-200).
- Pulse Width (FWHM): Approximately 2.2 ns to 2.5 ns.

To ensure maximum light collection and protect the detector from environmental interference, the scintillators undergo a specific wrapping process. The plastic material is first wrapped in aluminum foil that acts as a specular reflector. Than a layer of black vinyl or black tape is applied over the aluminum to provide a light-tight seal. This prevents ambient light from entering the system, which would increase the background noise or saturate the PMT.

The thinner scintillator (Minerva) is coupled to the PMT using a BC-802 Tapered Light Guide. Its geometry allows for the transition from the rectangular shape of scintillators to the circular window of the PMT. Minerva has the Hamamatsu R1924A-01 as PMT, a 1-inch diameter tube designed for fast timing and prepared for positive high voltage (HV). 

The other two scintillators (Partenope and Giunone) have similar characteristics for which we know only the constructor name (Saint-Gobain), but not the exact specifics. We know they require negative supply voltage.


== Supply voltages & Thresholds
We were now able to test the three scintillators we had: Partenope, Minerva, Giunone.
The first interesting thing to study was the relation between number of events, supply voltage and threshold of reading electronics. For a good scintillator-PMT apparatus we expected the output signal to be proportional to the energy released in the interaction by a particle.
Thus, at fixed supply voltage, we would expect the higher the threshold is after the PMT, the fewer events measured by a scintillator. For low threshold we expected many counts due to natural radioactivity, but we were interested in measuring the decay of the muon. Its energy scale is one order of magnitude greater than the one of natural radioactivity. Therefore, we expected some kind of plateaux where the natural radioactivity ends and there is only a constant rate of muons. 


 We first made some preliminary measurements. These measures were taken varying both the supply voltage and the threshold of the discriminator at the same time (or only one of them) for the three scintillators. These data helped us understanding the number of events we would expect and how much it should have been varying to different initial condition. The first idea was to map the two dimensional space of tension and threshold at the same time, but we soon realized it was a waste of energies and time. Thus, we decided to test the distribution of events at fixed supply voltage, increasing the threshold. We chose the supply voltages by visually analyzing the output of PMTs at the oscilloscope and maximizing it with respect to the maximum input the discriminator accepted (250 mV). Then, eventually, we would have lowered the supply tension and retake the measures. In this way, we were sure to respect the requirements of the instrumentation and be able to test all the scale of threshold our system had, searching for the plateaux. This was done for each scintillator. 

#figure( image("Plots/pg_th_old.pdf", width: 100%, fit: "contain"), caption: "Partenope and Giunone's count vs threshold", placement: top) <fig:pg_th> 

For what it concerns Giunone and Partenope scintillators, from @fig:pg_th it is evident that in this setup there were no plateaux. We made some hypotheses: it could be that we missed the plateaux because we took too big steps in threshold resolution or that it was at lower or higher threshold we couldn't set or it could be that the supply voltage wasn't high enough. 

We also studied the coincidences between the two, trying to maximize the ratio of coincidences and total number of events. But after some measurements we realized this procedure was too messy and wasteful because it depends on the thresholds and supply voltage of both scintillators. Plus, it also could lead us to some misinterpretation of the data because we only measured the double coincidences, so they were affected by casual coincidences and natural radioactivity (since we did not know the number of events from muons' interactions).
After having denied the idea of having missed the plateaux because of far too big steps, we thought that maybe the supply voltages of our instruments weren't high enough, so PMTs couldn't pre-amplify correctly the signal, which could lead to inaccurate signals. Thus, as discussed in @sec:discriminator, we changed the discriminator in order to widen the operational range. 

We were now able to scan the number of events respect to the thresholds at two different voltages. After analyzing the output of the detectors at the oscilloscope, we noticed that in order to have  similar responses to the same input, Giunone detector had to be powered with $~ 100 $ V more than Partenope. We decided to have similar impulses to the same particle interaction. 
// #image("Plots/Minerva.png") //preliminary plot devo aggiungerlo, cancellato!!!
// #todo("add 'nuova analisi' plot")
// #place(center + top, figure(image("Plots/giunone_th.pdf", width: 80%, fit: "contain"), caption: "Giunone threshold"))

#figure( image("Plots/partenope_th.pdf", width: 100%, fit: "contain"), caption: "Partenope's threshold", placement: top ) <fig:p_th> 

#figure( image("Plots/giunone_th.pdf", width: 100%, fit: "contain"), caption: "Giunone's threshold", placement: top) <fig:g_th> 

As it can be seen from the plots (@fig:g_th and @fig:p_th), for each of the two scintillators, we scanned the threshold at two different voltages: for the higher ones tested, we were able to recognize a plateaux for threshold between 130 mV to 175 mV. The plateaux isn't perfectly flat, but we can expect to cut some events going at higher thresholds (due to the energy distribution or fluctuations). Anyway, we decided to set the threshold at half of the plateaux. 

Minerva detector was already at the max supply voltage we could set (for PMT requirements), so we didn't change its one. As can be seen from the plot (@fig:m_th), for this scintillator we found some kind of plateaux. The plateaux was observed for Minerva scintillator from 157 to 186 mV.
//This was due to both the not perfect setup (Minerva scintillator-PMT) and to the difficulty in setting the exact threshold we wanted.
// We also noticed some fluctuations in the response of Minerva (*ref figure* (add figure)) and they would be helpful to motivate some issues in finding the decay rate of muons (*add ref to section*).
#figure( image("Plots/minerva_th.pdf", width: 100%, fit: "contain"), caption: "Minerva's count vs threshold", placement: top) <fig:m_th> 

#figure(table(columns: (auto, auto, auto),
 [],[ Supply voltage [V]], [Threshold [mV]], 
 [Partenope ], [880], [148],
 [Giunone ], [1050], [136],
 [Minerva ], [1200], [167],
),caption: [Scintillators operating characteristics],
  supplement: [Table], )


== Efficiency
Having decided the supply voltages and thresholds of the setup, we then decided to study the efficiencies of our instruments: we wanted to test our scintillators to understand the fraction of event registered respect to the number of total interactions. We did this for different configurations to verify also that no scintillator had any "dead zones". We couldn't know the absolute number of interactions, but we estimate it by using the counts of coincidences of the upper and lower scintillators. We defined $ epsilon = (\# "triple coincidences") / (\# "upper and lower scintillators coincedences") $ <eq:epsilon_def>

We put in the middle the scintillator we wanted to test and above and below the others. For a fixed time, we measured the number of triple coincidences of the three instruments and the number of double coincidences between the upper scintillator and the lower one. We then moved at fixed steps the central scintillator and retake the measurement. We ran a simulation to understand the number of data lost for solid angle (considering different distances among them) and we compared the results. Eventually, we repeated the procedure with the other two scintillators.
//ora scrivo prima una parte sulla simulazione

=== Simulations
We ran two simulations: the first was a Python simulation in which we considered only the solid angle factor, the other was a Geant4 simulation in which we simulate real interactions. For the first one, we wanted to have an order of magnitude of muons that interact with the upper and lower scintillators while misaligning the three instruments. With this, we did not considered a minimum path and energy released in each of them, but simply if a muon crossed the surface of the scintillator. The second one was a more complete simulation, where we could set energies of particles, kind of interactions, minimum energy released. The two simulation aren't fully compatible, but we do trust more the Geant4 simulation because of its reliability and completeness. With this last simulation we also set different muons distributions (as described in @chap:muons_prop) to understand which one cosmic muons have.

// We measured relative distances of scintillators along vertical axes in all the configurations we used for this part of experiment and we implemented this feature in each simulation. 
#figure( placement: top,
  image("Plots/immagine.png", width : 90%, height:200pt), caption: [Example of Geant4 simulation run: Minerva (yellow), Giunone (green), Partenope (red)]
)

=== Partenope & Giunone

For those scintillators we did two different simulation in which we varied the length of this detector: in the first simulation it was 80 cm, in the second one it was 75 cm. Since we do not have any technical scheme of the scintillator, we tried to understand how much 5 cm of light collector near the PMT would affect the measure. As can be seen in the following plots (@fig:p_res and @fig:p_res_1cm) the difference is very small, almost imperceptible. In these simulations we tried also different angular distribution of cosmic muons respect to the azimuthal angle, but none of them is really compatible with what we found experimentally.


#figure( image("Plots/pg_eff.pdf", width: 116%), caption: [Partenope and Giunone resolutions, 80 cm length] )<fig:p_res> 
#figure( image("Plots/pg_eff_m1cm.pdf", width: 116%), caption: [Partenope and Giunone resolutions, 75 cm length] )<fig:p_res_1cm> 


// As can be seen from @fig:p_res, Partenope resolution is about 99%, while Giunone resolution is a little lower, but above 98%. \
// We studied the fraction between $epsilon_("measured")$ over $epsilon_("theory")$ as can be seen from @fig:p_dist and @fig:g_dist. From these plots we can't really say we are sure about one of the probability density function of muons distributions as a function of zenith angle because none of them is exactly compatible.// But we can say that the distribution that approximates better our data is the one proportional to $cos^2(theta)$.

If we define the geometrical efficiency as the fraction $epsilon_("measured") / epsilon_("theory")$, with $epsilon$ defined in @eq:epsilon_def, both Partenope and Giunone's plots have an unexpected shape (see @fig:p_dist, @fig:p_dist_1cm, @fig:g_dist, @fig:g_dis_1cm). The efficiency drops almost linearly with the misalignment of the middle scintillator, even if it is about 98% (Giunone) and 99% (Partenope) when aligned. This makes us think that there can be some dead zones in this two scintillators, but we can't locate them inside the detector. This non-scintillating parts of the detector can be both non-functioning PVT volumes or non-scintillating components of the apparatus PMT-scintillator, like light guides or wrapping.
// This means that the most "sensitive" parts of the scintillators are the one at the two ends, maybe due to the fact that light is better collected by light guides #rem[ha senso?]. Even if with efficiencies of about 80\%, we can say this two scintillators had not any dead zones that could compromise our experiment. #rem[riscrivo, ma non so cosa]

#figure(image("Plots/p_eff_dist.pdf", width: 90%), caption: [$epsilon_("meas")  #text[/] epsilon_("theory") $ for Partenope, 80 cm length] )<fig:p_dist>
#figure(image("Plots/p_eff_dist_m1cm.pdf", width: 90%), caption: [$epsilon_("meas")  #text[/] epsilon_("theory") $ for Partenope, 75 cm length] )<fig:p_dist_1cm>
#figure(image("Plots/g_eff_dist.pdf", width: 90%), caption: [$epsilon_("meas") #text[/] epsilon_("theory") $ for Giunone, 80 cm length] )<fig:g_dist>
#figure(image("Plots/g_eff_dist_m1cm.pdf", width: 90%), caption: [$epsilon_("meas") #text[/] epsilon_("theory") $ for Giunone, 75 cm length] )<fig:g_dis_1cm>


Even though there are dead zones in Partenope and Giunone, we are satisfied by the high efficiency when they are aligned because this is the setup for then next measures.

=== Minerva
We can observe the plots for Minerva scintillator (@fig:m_res and @fig:m_res_diff_frac): this detector had a resolution of about 89% when completely aligned with the others. The "75 cm" label indicates that the length of Partenope and Giunone is 75 cm for that simulation (generated with a cosine distribution) because of what we said in the previous paragraph.
The resolution remains constant or slightly increase until 45 cm of misalignment and then it drops at about 60-70%.
// We think this was due to some fluctuation of the threshold set for the discriminator we saw during the data taking of only this measures. But it may be due also to some noise that the PMT generates when aligned with the upper and lower scintillators, since we can see the similar patter in the above plots for Partenope and Giunone (@fig:p_dist and @fig:g_dist).


#figure(image("Plots/m_eff_1cm.pdf", width: 90%), caption:[Minerva resolution])<fig:m_res> 

#figure(image("Plots/m_eff_dist_frac_1cm.pdf", width: 90%), caption: [$epsilon_("meas") #text[/] epsilon_("theory") $ for Minerva])<fig:m_res_diff_frac>

There is a sort of bump in this last plot where the efficiency is greater than 1, which means we measured an higher count of triple coincidences than the one we would expect due to solid angles. We can see a similar pattern also in the same plots for the other two scintillator. We can address this to the problems we saw with Minerva's PMT or it might be some interference of the PMT while it is in the middle of the other scintillators or the theoretical distributions don't describe our setup correctly. Also here we see that the dimensions of the scintillators are important, so ignoring the real dimension of two scintillators doesn't help understanding how performative Minerva is.


